

    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="#">Group_25</a></p>
        </div>
    </section>

</body>
</html>