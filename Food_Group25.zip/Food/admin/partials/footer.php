<div class="footer">
    <div class="wrapper">
        <p>2024 All rights reserved, Developed By - <a href="#"> Group 25</a></p>
    </div>
    </div>
    </body>
    </html>