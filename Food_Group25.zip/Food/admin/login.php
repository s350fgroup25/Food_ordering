<?php include('../config/constants.php'); ?>

<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Food Order Website - Login Page </title>
  <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<div class="Login">
    <h1 class="text-center">Login</h1>
    <?php 
        if(isset($_SESSION['login']))
        {
            echo $_SESSION['login'];
            unset($_SESSION['login']);
        }

        if(isset($_SESSION['no-login-message']))
        {
            echo $_SESSION['no-login-message'];
            unset($_SESSION['no-login-message']);
        }
    ?>
    <br>
    <form action="" method="POST">
    <table class="tbl-30">
        <tr>
            <td> Username</td>
            <td>
                <input type="text" name="username" placeholder="Enter Your username">
            </td>
        </tr>
        <tr>
            <td> Password:</td>
            <td>
                <input type="text" name="password" placeholder="Enter Your password">
            </td>
        </tr>
        <tr>
        <td colspan="2">
            <input type="submit" name="submit" value="Login" class="btn-secondary">
        </td>
    </tr>
    </table>
    </form>
    </div>
</body>
</html>

<?php 
if(isset($_POST['submit']))
{
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";

    $res = mysqli_query($conn,$sql);

    $count = mysqli_num_rows($res);
               
    if($count==1)
    {
        $_SESSION['login'] = "<div class='success'>Login Success</div>";

        $_SESSION['user'] = $username;


        header('location:'.SITEURL.'admin/');

    }
    else
    {
        $_SESSION['login'] = "<div class='error'>Login Fail</div>";
        header('location:'.SITEURL.'admin/login.php');
    }


}

?>
