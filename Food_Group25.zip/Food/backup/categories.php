<?php include('partials-front/menu.php'); ?>



    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <a href="category-foods.html">
            <div class="box-3 float-container">
                <img src="image0/pizza.png" alt="Pizza" class="img-responsive img-curve">

                <h3 class="float-text text-white">Pizza</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="image0/hamburger.png" alt="Burger" class="img-responsive img-curve">

                <h3 class="float-text text-white">Burger</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/ds1.jpg" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white">Dim Sum</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/ita.jpeg" alt="Pizza" class="img-responsive img-curve">

                <h3 class="float-text text-white">Italian cuisine</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/chinese.jpg" alt="Burger" class="img-responsive img-curve">

                <h3 class="float-text text-white">Chinese cuisine</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/wt.png" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white">Hong Kong cuisine</h3>
            </div>
            </a>
            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/cg1.jpg" alt="Pizza" class="img-responsive img-curve">

                <h3 class="float-text text-white">Congee</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/kimchi.jpg" alt="Burger" class="img-responsive img-curve">

                <h3 class="float-text text-white">Korean cuisine</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="icon/sushi.png" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white">Japanese cuisine</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="image0/ice_cream.png" alt="Pizza" class="img-responsive img-curve">

                <h3 class="float-text text-white">Dessert</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="image0/soda.png" alt="Burger" class="img-responsive img-curve">

                <h3 class="float-text text-white">Drinks</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="image0/salad.png" alt="Momo" class="img-responsive img-curve">

                <h3 class="float-text text-white">Salad</h3>
            </div>
            </a>

            

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->


    <?php include('partials-front/footer.php'); ?>