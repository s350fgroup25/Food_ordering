<?php include('partial-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-searcha text-center">
        <div class="container">
            
            <form action="food-search.html" method="POST">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <a href="category-foods.html">
            <div class="box-3 float-container">
            <img src="images/pizza1.jpg" alt="Dim Sum" class="img-responsive img-curve">

                <h3 class="float-text text-white">Dim Sum</h3> 
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/burger1.jpg" alt="Staple food" class="img-responsive img-curve">
                
                <h3 class="float-text text-white">Staple food</h3>
            </div>
            </a>

            <a href="#">
            <div class="box-3 float-container">
                <img src="images/momo1.jpg" alt="Side dishes" class="img-responsive img-curve">

                <h3 class="float-text text-white">Side dishes</h3>
            </div>
            </a>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-pizza1.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Italian Chicken and Vegetable Skillet</h4>
                    <p class="food-price">HKD$ 65</p>
                    <p class="food-detail">
                        Made with Italian Sauce, Chicken, and organice vegetables.
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="icon/cheeseburger.jpeg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Cheese Burger</h4>
                    <p class="food-price">HKD$ 45</p>
                    <p class="food-detail">
                        A hamburger with a slice of melted cheese, along side with lettuce, tomato,
                         onion and pickles etc.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-burger1.jpg" alt="Chicke Hawain Burger" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Peking Duck</h4>
                    <p class="food-price">HKD$ 80</p>
                    <p class="food-detail">
                        Delicious Peking Duck, JUICY Meat and CRISPY Skin!
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-momo1.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Ma Po Tofu</h4>
                    <p class="food-price">HKD$ 50</p>
                    <p class="food-detail">
                        Tasty and Spicy Ma Po Tofu. Made with simmered silken tofu with pork.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="icon/kimchi.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Kimchi Jjigae</h4>
                    <p class="food-price">HKD$ 70</p>
                    <p class="food-detail">
                    A classic Korean spicy stew made with napa cabbage kimchi, pork belly, and tofu.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="icon/momo.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chicken Steam Momo</h4>
                    <p class="food-price">HKD$ 30</p>
                    <p class="food-detail">
                        6 Dumplings that have a juicy Indian-spiced minced chicken filling with Spicy Red Chili Chutney!
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/menu-pizza1.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Fired Rice</h4>
                    <p class="food-price">$60</p>
                    <p class="food-detail">
                        Made with Rice, Chicken, Meat and organice vegetables.
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\honey_sesame_chicken.jpg" alt="Chicke Hawain Burger" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Honey Sesame Chicken</h4>
                    <p class="food-price">$100</p>
                    <p class="food-detail">
                        Made with Italian Sauce, Chicken, Honey, vegetables.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\sweet_and_sour_pork.jpg" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Sweet and Sour Pork</h4>
                    <p class="food-price">$75</p>
                    <p class="food-detail">
                        Made with Sauce, Pork, and organice vegetables.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\chow_mein.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chow Mein</h4>
                    <p class="food-price">$70</p>
                    <p class="food-detail">
                        Made with Noodles, Pork, and vegetables.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\spring_rolls.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Spring Rolls</h4>
                    <p class="food-price">$45</p>
                    <p class="food-detail">
                        Made with Meat, vegetables and wheat.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>


            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\sichuan_boiled_fish.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Sichuan Boiled Fish</h4>
                    <p class="food-price">$120</p>
                    <p class="food-detail">
                        Made with Fish, chili pepper, vegetables.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\dim_sum.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Xiao Long Bao</h4>
                    <p class="food-price">$58</p>
                    <p class="food-detail">
                        Made with Pork, wheat, filled with juicy soup inside.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images\char_siu_pork.jpg" alt="Chicke Hawain Momo" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Char Siu Pork</h4>
                    <p class="food-price">$90</p>
                    <p class="food-detail">
                        Made with Sauce, Pork, Rice.
                    </p>
                    <br>

                    <a href="#" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="clearfix"></div>

            

        </div>

        <p class="text-center">
            <a href="#">See All Foods</a>
        </p>
    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?>