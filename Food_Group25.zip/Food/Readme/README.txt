# Admin login 
username :root
password ：root

## How to Install and Use
1. Download and install XAMPP server and download the files of this project
2. Copy the folder of this project in your xampp/htdocs/folder
3. Start XAMMP > Start Apache and SQL server. 
4. Go to phpmyadmin and create a new database named 'food-order'
    http://localhost/phpmyadmin/
5. under food database created and click on 'Import' option in the top menu
6. Upload the food-order.sql file and import it
7.Open your web browser and check if you got the website running on your localhost()

Video that tell you how to use 
Video :


Normal page :http://localhost/Food/
Admin Login :http://localhost/Food/admin

We made this project by referring to the teachings on the youtube
Refer :  https://www.youtube.com/watch?v=ZBgTzx46B8s&list=PLBLPjjQlnVXXBheMQrkv3UROskC0K1ctW

We also rewrote the web page based on the Source code he provided
Source code : https://github.com/vijaythapa333/web-design-course-restaurant
