
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 
 */
public class Function {
    //class function for checking tel. no in LoginFrame
    public static boolean checkTel (String no){
        try{
            int num = Integer.parseInt(no);
            if(no.length()!=8){
                JOptionPane.showMessageDialog(null, "Please enter a 8 digital mobile phone number!");
                throw new IllegalArgumentException();
            }
            else{return true;}
        }
        catch(Exception e){
            return false;
        }
    }
    
    //class function for checking password in LoginFrame
    public static boolean checkPass(String s1, String s2){
        boolean hasDigit = false;
        boolean hasChar = false;
        
        //Return false if create password != confirm password
        if(!s1.equals(s2)){
            JOptionPane.showMessageDialog(null, "Please make sure the create password is same as the confirm password","Reminder",JOptionPane.WARNING_MESSAGE);
            return false;
        }
        //Return false if password length < 8
        else if(s1.length() < 8){
                JOptionPane.showMessageDialog(null, "The password should be more than 8 charactors","Reminder",JOptionPane.WARNING_MESSAGE);
                return false;
               
        }  
        
        //Return false if password doesn't contain charactor and digit 
        for (char c : s2.toCharArray()) {
            if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (Character.isLetter(c)) {
                hasChar = true;
            }
        }
        if (hasDigit && hasChar) {
            return true;
        }
        else{
            JOptionPane.showMessageDialog(null, "The password should contain integers and charactors","Reminder",JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }
    
    public static boolean checkEmail(String email){
        if(!email.contains("@")){
            JOptionPane.showMessageDialog(null, "Email address should contain '@'","Reminder",JOptionPane.WARNING_MESSAGE);
            return false;
        }
        else{
            return true;
        }
    }
    
}
